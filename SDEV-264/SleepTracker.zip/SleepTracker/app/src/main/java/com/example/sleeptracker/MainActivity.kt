package com.example.sleeptracker

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.core.content.ContextCompat


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val inputSleep = resources.openRawResource(R.raw.sleep)
        val fileText = inputSleep.bufferedReader().use { it.readLines() }

        val sleepTextViews = arrayOf<TextView>(
            findViewById(R.id.sleep1),
            findViewById(R.id.sleep2),
            findViewById(R.id.sleep3),
            findViewById(R.id.sleep4),
            findViewById(R.id.sleep5),
            findViewById(R.id.sleep6),
            findViewById(R.id.sleep7)
        )

        for (i in 0 until 7) {
            val timeSlept = fileText[i]
            sleepTextViews[i].text = ("You slept $timeSlept hours.")
            if (fileText[i].isNotEmpty()) {
                if (fileText[i].toInt() == 6 || fileText[i].toInt() == 10 ) {
                    sleepTextViews[i].setTextColor(ContextCompat.getColor(this, R.color.yellow))
                }
                else if (fileText[i].toInt() < 7 || fileText[i].toInt() > 9) {
                    sleepTextViews[i].setTextColor(ContextCompat.getColor(this, R.color.red))
                }
                else if (fileText[i].toInt() in 7..9) {
                    sleepTextViews[i].setTextColor(ContextCompat.getColor(this, R.color.green))
                }
            }
        }
        val formattedString = intent.getStringExtra("formattedString")
        sleepTextViews[0].text = formattedString
        sleepTextViews[0].setTextColor(ContextCompat.getColor(this, R.color.green))
    }


    fun Home(view: View) {
        var home = Intent(this,MainActivity::class.java)
        startActivity(home)
    }
    fun AddSleep(view: View) {
        var addSleep = Intent(this,AddSleep::class.java)
        startActivity(addSleep)
    }
    fun Settings(view: View) {
        var preferences = Intent(this,Preferences::class.java)
        startActivity(preferences)
    }
    fun AboutUs(view: View) {
        var aboutUs = Intent(this,AboutUs::class.java)
        startActivity(aboutUs)
    }

}
