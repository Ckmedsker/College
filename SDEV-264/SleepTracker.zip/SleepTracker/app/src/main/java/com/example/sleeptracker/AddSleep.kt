package com.example.sleeptracker

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast

class AddSleep : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_sleep)
    }
    fun submit(view: View) {
        val fellAsleep = findViewById(R.id.fellAsleep) as EditText
        val wokeUp = findViewById(R.id.wokeUp) as EditText
        if (fellAsleep != null && wokeUp != null) {
            val fellAsleepString = fellAsleep.text.toString().toInt()
            val wokeUpString = wokeUp.text.toString().toInt()
            val timeSlept = wokeUpString - fellAsleepString
            val formattedString = "You slept $timeSlept hours."
            var home = Intent(this,MainActivity::class.java)
            home.putExtra("formattedString", formattedString)
            startActivity(home)
        }
    }
    fun Home(view: View) {
        var home = Intent(this,MainActivity::class.java)
        startActivity(home)
    }
    fun AddSleep(view: View) {
        var addSleep = Intent(this,AddSleep::class.java)
        startActivity(addSleep)
    }
    fun Settings(view: View) {
        var preferences = Intent(this,Preferences::class.java)
        startActivity(preferences)
    }
    fun AboutUs(view: View) {
        var aboutUs = Intent(this,AboutUs::class.java)
        startActivity(aboutUs)
    }


}
