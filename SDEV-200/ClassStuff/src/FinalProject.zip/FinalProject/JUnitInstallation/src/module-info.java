/**
 * 
 */
/**
 * @author Camer
 *
 */
module JUnitInstallation {
}