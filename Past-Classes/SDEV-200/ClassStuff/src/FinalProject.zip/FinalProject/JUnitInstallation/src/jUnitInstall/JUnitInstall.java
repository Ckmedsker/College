package jUnitInstall;

public class JUnitInstall {

}
